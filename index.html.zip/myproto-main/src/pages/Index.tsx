import { useLenis } from "@/hooks/useLenis";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import About from "@/components/About";
import Process from "@/components/Process";
import Projects from "@/components/Projects";
import Contact from "@/components/Contact";
import InteractiveBackground from "@/components/InteractiveBackground";

const Index = () => {
  useLenis();

  return (
    <main className="relative">
      <InteractiveBackground />
      <Navbar />
      <Hero />
      <Marquee />
      <About />
      <Process />
      <Projects />
      <Contact />
    </main>
  );
};

export default Index;
