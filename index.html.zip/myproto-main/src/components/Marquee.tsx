const items = [
  "React", "Next.js", "TypeScript", "Node.js", "Python",
  "PostgreSQL", "Tailwind", "Three.js", "MongoDB", "Docker",
  "GraphQL", "AWS", "Framer Motion", "Prisma",
];

const Marquee = () => {
  return (
    <div className="relative overflow-hidden py-10 border-y border-border/50">
      <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
      <div className="flex animate-marquee whitespace-nowrap">
        {[...items, ...items].map((item, i) => (
          <span
            key={i}
            className="mx-8 text-3xl md:text-5xl font-display font-semibold text-muted-foreground/60 hover:text-foreground transition-colors"
          >
            {item} <span className="text-primary">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
};

export default Marquee;
