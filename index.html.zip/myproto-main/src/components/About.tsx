import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const About = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], ["-15%", "15%"]);
  const labelX = useTransform(scrollYProgress, [0, 1], ["-30%", "30%"]);

  const facts = [
    ["01", "Based in", "India · Remote"],
    ["02", "Focus", "Full Stack · Web"],
    ["03", "Stack", "TS · React · Node"],
    ["04", "Status", "Open to projects"],
  ];

  return (
    <section id="about" ref={ref} className="relative py-32 overflow-hidden">
      {/* Giant background label that scrolls horizontally */}
      <motion.div
        style={{ x: labelX }}
        aria-hidden
        className="absolute -top-10 left-0 right-0 pointer-events-none whitespace-nowrap font-display text-[24vw] font-bold leading-none text-foreground/[0.04] select-none"
      >
        ABOUT — ABOUT — ABOUT
      </motion.div>

      <div className="container px-6 relative">
        <div className="grid md:grid-cols-12 gap-10 items-start">
          {/* Left: editorial label + portrait */}
          <div className="md:col-span-5 md:sticky md:top-32">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-primary" />
              <span className="text-xs uppercase tracking-[0.3em] text-primary">§ 01 — Profile</span>
            </div>

            <div className="relative aspect-[4/5] rounded-3xl glass overflow-hidden gradient-border">
              <motion.div
                style={{ y: imageY }}
                className="absolute -inset-10 bg-gradient-aurora opacity-50 animate-gradient-shift bg-[length:200%_200%]"
              />
              <div className="absolute inset-0 noise" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-serif-display text-[16rem] leading-none gradient-text">H</span>
              </div>

              {/* meta footer */}
              <div className="absolute inset-x-4 bottom-4 glass-strong rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Currently</p>
                  <p className="text-sm font-medium mt-1">Building with React & Node</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-primary animate-pulse-glow" />
              </div>
            </div>
          </div>

          {/* Right: editorial copy */}
          <div className="md:col-span-7 md:pl-8">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="font-display text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.05] text-balance"
            >
              I'm <span className="font-serif-display gradient-text">Harshit</span> — a developer
              who treats <span className="font-serif-display gradient-text">code</span> like craft.
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15, duration: 0.7 }}
              className="mt-10 grid sm:grid-cols-2 gap-6 text-muted-foreground"
            >
              <p className="text-base leading-relaxed">
                I design and build products end-to-end — from the first wireframe
                to the last line of API code. My obsession is <span className="text-foreground font-medium">detail</span>:
                the easing of a button, the cache hit on an endpoint, the
                contrast on a loading state.
              </p>
              <p className="text-base leading-relaxed">
                I work best when design and engineering meet. I love clean
                interfaces, thoughtful animation, fast databases, and code that
                a teammate can read at <span className="text-foreground font-medium">3 a.m.</span> and still understand.
              </p>
            </motion.div>

            {/* Editorial fact list */}
            <div className="mt-14 border-t border-border">
              {facts.map(([n, k, v], i) => (
                <motion.div
                  key={n}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 + i * 0.08 }}
                  className="grid grid-cols-12 items-center gap-4 py-5 border-b border-border group hover:bg-white/[0.02] transition-colors"
                >
                  <span className="col-span-2 md:col-span-1 text-xs text-muted-foreground tabular-nums">{n}</span>
                  <span className="col-span-4 md:col-span-3 text-sm uppercase tracking-widest text-muted-foreground">{k}</span>
                  <span className="col-span-6 md:col-span-8 font-display text-lg md:text-2xl group-hover:gradient-text transition-all">{v}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
