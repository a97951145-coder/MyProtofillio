import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Code2, Layers, Zap, Sparkles } from "lucide-react";

const steps = [
  {
    n: "01",
    icon: Sparkles,
    title: "Discover",
    body: "Listening, sketching, asking the awkward questions. Every great product starts with the right problem to solve.",
    accent: "from-primary/30 to-accent/30",
  },
  {
    n: "02",
    icon: Layers,
    title: "Design",
    body: "Wireframes, motion studies, type pairings, color systems. I treat the interface as the product, not its skin.",
    accent: "from-accent/30 to-secondary/30",
  },
  {
    n: "03",
    icon: Code2,
    title: "Build",
    body: "Type-safe React on the front, robust APIs on the back. Tests where they matter, performance where it shows.",
    accent: "from-secondary/30 to-primary/30",
  },
  {
    n: "04",
    icon: Zap,
    title: "Ship",
    body: "Deploy, measure, iterate. I obsess over Core Web Vitals so users feel speed before they notice anything else.",
    accent: "from-primary/30 to-secondary/30",
  },
];

const Process = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const titleY = useTransform(scrollYProgress, [0, 1], ["20%", "-20%"]);

  return (
    <section id="skills" ref={ref} className="relative py-32 overflow-hidden">
      <div className="container px-6">
        <div className="grid md:grid-cols-12 gap-10 mb-20">
          <div className="md:col-span-5 md:sticky md:top-32 md:self-start">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-primary" />
              <span className="text-xs uppercase tracking-[0.3em] text-primary">§ 02 — Process</span>
            </div>
            <motion.h2
              style={{ y: titleY }}
              className="font-display text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.02] text-balance"
            >
              From <span className="font-serif-display gradient-text">spark</span> to
              <br />
              <span className="font-serif-display gradient-text">shipped</span>.
            </motion.h2>
            <p className="mt-6 text-muted-foreground max-w-md">
              A simple, repeatable craft for building products that feel
              inevitable in hindsight.
            </p>
          </div>

          {/* Sticky stacking cards */}
          <div className="md:col-span-7 space-y-6">
            {steps.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div
                  key={s.n}
                  initial={{ opacity: 0, y: 60 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.7, delay: i * 0.05, ease: [0.65, 0, 0.35, 1] }}
                  style={{
                    position: "sticky",
                    top: `${100 + i * 24}px`,
                  }}
                  className="relative"
                >
                  <div className={`relative glass rounded-3xl p-8 md:p-10 overflow-hidden gradient-border`}>
                    <div className={`absolute -inset-px rounded-3xl bg-gradient-to-br ${s.accent} opacity-30 pointer-events-none`} />
                    <div className="relative z-10 flex flex-col md:flex-row md:items-start gap-6">
                      <div className="flex items-center gap-4 md:flex-col md:items-start md:gap-3 md:w-32 shrink-0">
                        <span className="font-display text-5xl md:text-6xl font-bold text-foreground/30">{s.n}</span>
                        <div className="w-12 h-12 rounded-2xl glass-strong flex items-center justify-center">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-display text-3xl md:text-4xl font-bold">{s.title}</h3>
                        <p className="mt-3 text-muted-foreground text-pretty leading-relaxed">{s.body}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;
