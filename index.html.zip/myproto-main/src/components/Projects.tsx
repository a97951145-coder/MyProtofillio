import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    n: "001",
    year: "2024",
    title: "Nimbus Analytics",
    role: "Full Stack · Design",
    description: "Real-time analytics dashboard with live charts, custom queries, and team workspaces.",
    tags: ["Next.js", "PostgreSQL", "WebSocket"],
    gradient: "from-purple-500 via-fuchsia-500 to-pink-500",
  },
  {
    n: "002",
    year: "2024",
    title: "Orbit Commerce",
    role: "Engineering Lead",
    description: "Headless e-commerce platform with custom checkout, Stripe integration & blazing-fast SSR.",
    tags: ["React", "Node", "Stripe"],
    gradient: "from-cyan-500 via-blue-500 to-indigo-500",
  },
  {
    n: "003",
    year: "2023",
    title: "Lumen AI",
    role: "Full Stack",
    description: "AI-powered writing assistant with streaming responses and contextual memory.",
    tags: ["TypeScript", "OpenAI", "Edge"],
    gradient: "from-emerald-500 via-teal-500 to-cyan-500",
  },
  {
    n: "004",
    year: "2023",
    title: "Pulse DevTool",
    role: "Open Source",
    description: "Open-source dev tool for monitoring API calls, request inspection & performance traces.",
    tags: ["Electron", "Python", "WebRTC"],
    gradient: "from-amber-500 via-orange-500 to-rose-500",
  },
];

const Projects = () => {
  return (
    <section id="work" className="relative py-32 overflow-hidden">
      <div className="container px-6">
        {/* header */}
        <div className="grid md:grid-cols-12 gap-6 items-end mb-16">
          <div className="md:col-span-7">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-primary" />
              <span className="text-xs uppercase tracking-[0.3em] text-primary">§ 03 — Selected Work</span>
            </div>
            <h2 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.02] text-balance">
              Things I've <span className="font-serif-display gradient-text">built</span> &
              <br />
              shipped <span className="font-serif-display gradient-text">recently</span>.
            </h2>
          </div>
          <p className="md:col-span-5 text-muted-foreground md:text-right">
            A curated set of products spanning analytics, commerce, AI tooling
            and developer experience.
          </p>
        </div>

        {/* Editorial list of projects */}
        <ul className="border-t border-border">
          {projects.map((p, i) => (
            <motion.li
              key={p.n}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: i * 0.05 }}
              className="border-b border-border group"
            >
              <a href="#" className="block relative py-8 md:py-10 px-2 md:px-4 transition-colors hover:bg-white/[0.02]">
                {/* hover gradient strip */}
                <div className={`absolute inset-y-0 left-0 w-0 group-hover:w-1.5 bg-gradient-to-b ${p.gradient} transition-all duration-500`} />

                <div className="grid grid-cols-12 gap-4 items-center">
                  <span className="col-span-2 md:col-span-1 font-mono text-xs text-muted-foreground tabular-nums">{p.n}</span>

                  <div className="col-span-10 md:col-span-5">
                    <h3 className="font-display text-2xl md:text-4xl lg:text-5xl font-bold leading-tight transition-all duration-500 group-hover:translate-x-2">
                      <span className="group-hover:gradient-text transition-all">{p.title}</span>
                    </h3>
                  </div>

                  <p className="col-start-3 md:col-start-auto col-span-10 md:col-span-3 text-sm text-muted-foreground text-pretty">
                    {p.description}
                  </p>

                  <div className="hidden md:flex md:col-span-2 flex-wrap gap-1.5">
                    {p.tags.slice(0, 2).map((t) => (
                      <span key={t} className="px-2.5 py-1 rounded-full text-[10px] font-medium border border-border text-muted-foreground">
                        {t}
                      </span>
                    ))}
                  </div>

                  <div className="hidden md:flex md:col-span-1 items-center justify-end gap-3">
                    <span className="text-xs text-muted-foreground tabular-nums">{p.year}</span>
                    <span className="w-10 h-10 rounded-full glass flex items-center justify-center group-hover:bg-gradient-primary group-hover:rotate-45 transition-all duration-500">
                      <ArrowUpRight className="w-4 h-4" />
                    </span>
                  </div>

                  {/* mobile arrow */}
                  <div className="md:hidden col-span-12 mt-3 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1.5">
                      {p.tags.map((t) => (
                        <span key={t} className="px-2 py-0.5 rounded-full text-[10px] font-medium border border-border text-muted-foreground">
                          {t}
                        </span>
                      ))}
                    </div>
                    <span className="w-9 h-9 rounded-full glass flex items-center justify-center">
                      <ArrowUpRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </a>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default Projects;
