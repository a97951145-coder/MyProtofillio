import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";

import { ArrowDown, Sparkles } from "lucide-react";

const VIMEO_ID = "828568593";
// Vimeo's public poster image — same frame the player uses
const VIMEO_POSTER = `https://vumbnail.com/${VIMEO_ID}.jpg`;

const Hero = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [videoReady, setVideoReady] = useState(false);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  // Fallback: assume the video is playing after 2.5s even if onLoad never fires
  useEffect(() => {
    const t = setTimeout(() => setVideoReady(true), 2500);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      ref={ref}
      id="top"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Vimeo video background — static container so Vimeo doesn't auto-pause on transform */}
      <div className="absolute inset-0 z-0 overflow-hidden bg-background">
        {/* Poster image shown until the iframe is ready */}
        <img
          src={VIMEO_POSTER}
          alt=""
          aria-hidden
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${
            videoReady ? "opacity-0" : "opacity-100"
          }`}
        />
        <iframe
          src={`https://player.vimeo.com/video/${VIMEO_ID}?background=1&autoplay=1&loop=1&muted=1&controls=0&autopause=0&dnt=1&playsinline=1`}
          allow="autoplay; fullscreen; picture-in-picture"
          onLoad={() => setVideoReady(true)}
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[177.77vh] h-[56.25vw] min-w-full min-h-full pointer-events-none border-0 transition-opacity duration-700 ${
            videoReady ? "opacity-100" : "opacity-0"
          }`}
          title="Hero background"
        />
      </div>

      {/* Dark overlay for text legibility */}
      <div className="absolute inset-0 bg-background/40 z-[1] pointer-events-none" />

      {/* Soft vignette */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/10 to-background pointer-events-none z-[1]" />

      {/* Editorial corner labels */}
      <div className="absolute top-28 left-6 md:left-10 z-10 hidden sm:block">
        <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground/80">
          Portfolio<br />— Vol. 01
        </div>
      </div>
      <div className="absolute top-28 right-6 md:right-10 z-10 hidden sm:block text-right">
        <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground/80">
          {new Date().getFullYear()}<br />India · Remote
        </div>
      </div>

      {/* Hero content */}
      <motion.div
        style={{ opacity, y }}
        className="relative z-10 container px-6 text-center"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-8"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
          </span>
          <span className="text-xs font-medium text-muted-foreground">Available for new projects</span>
          <Sparkles className="w-3.5 h-3.5 text-primary" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="font-display text-[clamp(2.75rem,9vw,8rem)] font-bold leading-[0.92] tracking-tight text-balance"
        >
          <span className="block">Harshit Dubey</span>
          <span className="block mt-2">
            <span className="font-serif-display gradient-text">building</span>{" "}
            <span className="gradient-text">the modern web</span>
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-8 max-w-2xl mx-auto text-base sm:text-lg text-muted-foreground text-pretty"
        >
          Full Stack Web Developer & Programmer crafting fast, beautiful, and
          scalable digital experiences from idea to deployment.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="mt-10 flex items-center justify-center gap-4 flex-wrap"
        >
          <a
            href="#work"
            className="group relative inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-primary text-primary-foreground font-medium shadow-glow hover:scale-105 transition-transform duration-300"
          >
            View my work
            <ArrowDown className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
          </a>
          <a
            href="mailto:a97951145@gmail.com"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full glass hover:bg-white/10 transition-colors duration-300 font-medium"
          >
            Get in touch
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <div className="w-6 h-10 rounded-full border border-border flex items-start justify-center p-1.5">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.8, repeat: Infinity }}
            className="w-1 h-2 rounded-full bg-foreground"
          />
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;
