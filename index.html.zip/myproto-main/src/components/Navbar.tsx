import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const links = [
  { href: "#about", label: "About" },
  { href: "#work", label: "Work" },
  { href: "#skills", label: "Skills" },
  { href: "#contact", label: "Contact" },
];

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.65, 0, 0.35, 1] }}
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[min(960px,92%)]"
    >
      <nav
        className={`glass rounded-full px-5 py-3 flex items-center justify-between transition-all duration-500 ${
          scrolled ? "shadow-elegant" : ""
        }`}
      >
        <a href="#top" className="flex items-center gap-2 group">
          <span className="w-8 h-8 rounded-full bg-gradient-primary animate-gradient-shift bg-[length:200%_200%] shadow-glow" />
          <span className="font-display font-semibold tracking-tight">Harshit<span className="text-primary">.</span></span>
        </a>
        <ul className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground rounded-full transition-colors duration-300 hover:bg-white/5"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="mailto:a97951145@gmail.com"
          className="relative inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium bg-gradient-primary text-primary-foreground shadow-glow hover:scale-105 transition-transform duration-300"
        >
          Hire me
        </a>
      </nav>
    </motion.header>
  );
};

export default Navbar;
