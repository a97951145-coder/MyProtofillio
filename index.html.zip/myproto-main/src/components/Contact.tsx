import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Mail, ArrowUpRight, Github, Linkedin, Twitter } from "lucide-react";

const Contact = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const wordX = useTransform(scrollYProgress, [0, 1], ["-15%", "5%"]);
  const wordX2 = useTransform(scrollYProgress, [0, 1], ["10%", "-10%"]);

  return (
    <section id="contact" ref={ref} className="relative pt-32 pb-12 overflow-hidden">
      <div className="container px-6">
        <div className="flex items-center gap-3 mb-10">
          <span className="w-10 h-px bg-primary" />
          <span className="text-xs uppercase tracking-[0.3em] text-primary">§ 04 — Get in Touch</span>
        </div>

        {/* Oversized typographic CTA */}
        <div className="relative">
          <motion.h2
            style={{ x: wordX }}
            className="font-display font-bold leading-[0.85] tracking-tight text-balance text-[clamp(3.5rem,14vw,12rem)]"
          >
            Let's <span className="font-serif-display gradient-text">build</span>
          </motion.h2>
          <motion.h2
            style={{ x: wordX2 }}
            className="font-display font-bold leading-[0.85] tracking-tight text-balance text-[clamp(3.5rem,14vw,12rem)] mt-2"
          >
            something <span className="font-serif-display gradient-text">real.</span>
          </motion.h2>
        </div>

        {/* Email + socials card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mt-16 glass rounded-3xl p-8 md:p-12 relative overflow-hidden gradient-border"
        >
          <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-accent/20 blur-3xl pointer-events-none" />

          <div className="relative z-10 grid md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-7">
              <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Drop a line</p>
              <a
                href="mailto:a97951145@gmail.com"
                className="group mt-3 inline-flex items-center gap-3 font-display text-2xl md:text-4xl font-semibold hover:gradient-text transition-all"
              >
                <Mail className="w-6 h-6 text-primary shrink-0" />
                <span className="break-all">a97951145@gmail.com</span>
                <ArrowUpRight className="w-5 h-5 shrink-0 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
              <p className="mt-4 text-muted-foreground max-w-md">
                Whether it's a freelance project, a full-time role or just a
                friendly hello — I read every message.
              </p>
            </div>

            <div className="md:col-span-5 md:border-l md:border-border md:pl-10">
              <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Find me</p>
              <div className="mt-4 flex flex-col gap-3">
                {[
                  { icon: Github, href: "#", label: "GitHub", handle: "@harshitdubey" },
                  { icon: Linkedin, href: "#", label: "LinkedIn", handle: "in/harshit-dubey" },
                  { icon: Twitter, href: "#", label: "Twitter", handle: "@harshit__d" },
                ].map(({ icon: Icon, href, label, handle }) => (
                  <a
                    key={label}
                    href={href}
                    className="group flex items-center justify-between gap-4 px-4 py-3 rounded-2xl glass-strong hover:bg-white/[0.06] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">{label}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="hidden sm:inline">{handle}</span>
                      <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Footer */}
        <footer className="mt-16 grid md:grid-cols-3 gap-6 items-center text-sm text-muted-foreground border-t border-border pt-8">
          <p>© {new Date().getFullYear()} Harshit Dubey</p>
          <p className="font-serif-display italic text-center">"Code is poetry written for machines."</p>
          <p className="md:text-right">Designed & built in <span className="text-foreground">India</span></p>
        </footer>
      </div>
    </section>
  );
};

export default Contact;
