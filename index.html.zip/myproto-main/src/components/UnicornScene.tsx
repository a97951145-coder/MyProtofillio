import { useEffect, useRef } from "react";

declare global {
  interface Window {
    UnicornStudio?: {
      isInitialized: boolean;
      init?: () => void;
    };
  }
}

interface UnicornSceneProps {
  projectId: string;
  className?: string;
}

const SCRIPT_SRC =
  "https://cdn.jsdelivr.net/gh/hiunicornstudio/unicornstudio.js@v2.1.9/dist/unicornStudio.umd.js";

const UnicornScene = ({ projectId, className }: UnicornSceneProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ensureInit = () => {
      if (window.UnicornStudio?.init) {
        try {
          window.UnicornStudio.init();
        } catch (e) {
          console.error("UnicornStudio init failed", e);
        }
      }
    };

    if (window.UnicornStudio?.init) {
      ensureInit();
      return;
    }

    // Avoid duplicate script injection
    const existing = document.querySelector<HTMLScriptElement>(
      `script[src="${SCRIPT_SRC}"]`
    );
    if (existing) {
      existing.addEventListener("load", ensureInit, { once: true });
      return;
    }

    window.UnicornStudio = window.UnicornStudio || { isInitialized: false };
    const script = document.createElement("script");
    script.src = SCRIPT_SRC;
    script.async = true;
    script.onload = ensureInit;
    document.head.appendChild(script);
  }, [projectId]);

  return (
    <div
      ref={containerRef}
      data-us-project={projectId}
      className={className}
    />
  );
};

export default UnicornScene;
