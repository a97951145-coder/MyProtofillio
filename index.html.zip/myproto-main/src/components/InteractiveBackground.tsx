import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, MeshDistortMaterial } from "@react-three/drei";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

/* -------- Single 3D ball with lighting + subtle distortion -------- */
const Ball = ({
  position,
  color,
  scrollRef,
  mouseRef,
  speed = 1,
  size = 1,
  distort = 0.35,
}: {
  position: [number, number, number];
  color: string;
  scrollRef: React.MutableRefObject<number>;
  mouseRef: React.MutableRefObject<{ x: number; y: number }>;
  speed?: number;
  size?: number;
  distort?: number;
}) => {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!meshRef.current) return;
    const t = state.clock.elapsedTime * speed;
    const scroll = scrollRef.current;
    const mx = mouseRef.current.x;
    const my = mouseRef.current.y;

    meshRef.current.position.x = position[0] + Math.sin(t * 0.5) * 0.4 + mx * 0.6;
    meshRef.current.position.y = position[1] + Math.cos(t * 0.4) * 0.4 - scroll * 5 + my * 0.4;
    meshRef.current.position.z = position[2] + Math.sin(t * 0.3) * 0.3;

    meshRef.current.rotation.x += 0.003;
    meshRef.current.rotation.y += 0.004;
  });

  return (
    <Float speed={1.5} rotationIntensity={0.4} floatIntensity={0.8}>
      <mesh ref={meshRef} position={position} castShadow receiveShadow>
        <sphereGeometry args={[size, 64, 64]} />
        <MeshDistortMaterial
          color={color}
          roughness={0.15}
          metalness={0.6}
          distort={distort}
          speed={2}
          envMapIntensity={1.2}
        />
      </mesh>
    </Float>
  );
};

/* -------- Main interactive 3D background -------- */
const InteractiveBackground = () => {
  const scrollRef = useRef(0);
  const mouseRef = useRef({ x: 0, y: 0 });
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);

    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      scrollRef.current = max > 0 ? window.scrollY / max : 0;
    };
    const onMouse = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = -((e.clientY / window.innerHeight) * 2 - 1);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("mousemove", onMouse, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("mousemove", onMouse);
    };
  }, []);

  if (reduced) {
    return <div aria-hidden className="fixed inset-0 -z-10 bg-background pointer-events-none" />;
  }

  return (
    <div
      aria-hidden
      className="fixed inset-0 -z-10 pointer-events-none bg-background"
    >
      <Canvas
        camera={{ position: [0, 0, 9], fov: 55 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        style={{ position: "absolute", inset: 0 }}
      >
        {/* Lighting setup for proper 3D shading */}
        <ambientLight intensity={0.4} />
        <directionalLight position={[5, 5, 5]} intensity={1.2} />
        <pointLight position={[-6, -3, 4]} intensity={1.5} color="#a855f7" />
        <pointLight position={[6, 3, -2]} intensity={1.5} color="#ec4899" />
        <pointLight position={[0, -5, 3]} intensity={1} color="#38bdf8" />

        {/* Environment for reflections */}
        <Environment preset="city" />

        {/* 3D Balls */}
        <Ball
          position={[-4, 1.5, -1]}
          color="#a855f7"
          scrollRef={scrollRef}
          mouseRef={mouseRef}
          speed={0.6}
          size={1.2}
          distort={0.4}
        />
        <Ball
          position={[4, -1, -2]}
          color="#ec4899"
          scrollRef={scrollRef}
          mouseRef={mouseRef}
          speed={0.5}
          size={1.4}
          distort={0.3}
        />
        <Ball
          position={[0, 2.5, -3]}
          color="#38bdf8"
          scrollRef={scrollRef}
          mouseRef={mouseRef}
          speed={0.4}
          size={1}
          distort={0.45}
        />
        <Ball
          position={[-3, -2.5, 0]}
          color="#f59e0b"
          scrollRef={scrollRef}
          mouseRef={mouseRef}
          speed={0.7}
          size={0.8}
          distort={0.35}
        />
        <Ball
          position={[3.5, 2, -4]}
          color="#10b981"
          scrollRef={scrollRef}
          mouseRef={mouseRef}
          speed={0.55}
          size={0.9}
          distort={0.3}
        />
      </Canvas>

      {/* Bottom fade so content always reads */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-transparent to-background/70" />
    </div>
  );
};

export default InteractiveBackground;
